"""Examples routines."""

from pyvista.examples.downloads import *
from pyvista.examples.examples import *
